#include <stdio.h>
#include <stdlib.h>

int main()
{
    struct time
    {
        int min;
        int sec; //0-59
    };

    struct runner
    {
        char firstName[30];
        char lastName[30];
        char ID[30];
        struct time *record;
        struct time runningTime;
    };

    int player;
    printf("number of players:\n");
    scanf("%d", &player);

    struct runner info[player];
    int i;

    for( i = 0 ; i < player ; i++ )
    {
        printf("first name[%d]:\n", i+1);
        scanf("%s", (info[i].firstName) );
        printf("last name[%d]:\n", i+1);
        scanf("%s", (info[i].lastName) );
        printf("ID[%d]:\n", i+1);
        scanf("%s", (info[i].ID) );
        info[i].record = (struct time*)malloc(sizeof(struct time)); 
        printf("min for record:\n");
        scanf("%d", &((info[i].record)->min) );
        printf("sec for record:\n");
        scanf("%d", &((info[i].record)->sec) );
        printf("min for runnig time:\n");
        scanf("%d", &(info[i].runningTime.min) );
        printf("sec for running time:\n");
        scanf("%d", &(info[i].runningTime.sec) );
    }

    /*for( i = 0 ; i < player ; i++ )
    {
        printf("firstname[%d]= %s\n", i+1, info[i].firstName);
        printf("last name[%d]= %s\n", i+1, info[i].lastName );
        printf("ID[%d]= %s\n", i+1, info[i].ID);
        printf("min for record[%d]= %d\n", i+1, ((info[i].record)->min));
        printf("sec for record[%d]= %d\n", i+1, ((info[i].record)->sec));
        printf("min for runnig time[%d]= %d\n", i+1, (info[i].runningTime.min));
        printf("sec for running time[%d]= %d\n", i+1, (info[i].runningTime.sec));
    }*/

    int recALL[player];
    int recNOW[player];

    for( i = 0 ; i < player ; i++ )
    {
        recALL[i] = (((info[i].record)->min)*60) + (((info[i].record)->sec));
        recNOW[i] = ((info[i].runningTime.min)*60) + (info[i].runningTime.sec);
    }

    int winner = recNOW[0];
    int numwinner = 0;

    for( i = 1 ; i < player ; i++ )
    {
        if( recNOW[i] < winner )
        {
            winner = recNOW[i];
            numwinner = i;
        }
    }

    printf("winner is: %s %s\n", info[numwinner].firstName, info[numwinner].lastName);

    if( winner < recALL[numwinner] )
    {
        printf("player broke his record.\n");
    }
    else
    {
        printf("player did not break his record.\n");
    }

    int winnerALL = recALL[0];
    int numwinnerALL = 0;

    for( i = 1 ; i < player ; i++ )
    {
        if( recALL[i] < winnerALL )
        {
            winnerALL = recALL[i];
            numwinnerALL = i;
        }
    }

    if( winner < recALL[numwinnerALL] )
    {
        printf("player broke all time record.\n");
    }
    else
    {
        printf("player did not break all time record.\n");
    }

    int j;
    struct runner sort;

    for( i = 0 ; i < player ; i++ )
    {
        for( j = i + 1 ; j < player ; j++ )
        {
            if(recNOW[i] < recNOW[j])
            {
                sort = info[i];
                info[i] = info[j];
                info[j] = sort;
            }
        }
    }
    //> khata dad chera; for baadi i=0

    printf("FirstName      LastName       ID        ");
    printf("MINrecord SECrecord MINrunningTime SECrunningTime \n");

    for( i = player - 1  ; i >= 0 ; i-- )
    {
        printf("%-15s", info[i].firstName);
        printf("%-15s", info[i].lastName );
        printf("%-10s", info[i].ID);
        printf("%-10d", ((info[i].record)->min));
        printf("%-10d", ((info[i].record)->sec));
        printf("%-15d", (info[i].runningTime.min));
        printf("%-15d\n", info[i].runningTime.sec);
    }
}